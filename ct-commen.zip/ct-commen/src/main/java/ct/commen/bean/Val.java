package ct.commen.bean;

public interface Val {
    public void setValue(Object val);
    public Object getValue();
}
