package ct.commen.bean;

import java.io.Closeable;

public interface Producer extends Closeable {
    public void setIn(Datain in);
    public void setOut(Dataout out);

    /**
     *
     */
    public void produce();
}
