package ct.commen.constant;

public class ValueConstant {
    public static final Integer REGION_COUNT = 6;
}
