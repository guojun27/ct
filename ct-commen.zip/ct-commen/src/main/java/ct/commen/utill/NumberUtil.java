package ct.commen.utill;

import java.text.DecimalFormat;
import java.util.Random;

/*
数字工具类，吧数字格式化为字符串
 */
public class NumberUtil {
    public static String format(int num,int length){
        StringBuilder stringBuilder = new StringBuilder();
        for(int i=1;i<length+1;i++){
            stringBuilder.append("0");
        }
        DecimalFormat df = new DecimalFormat(stringBuilder.toString());
        return df.format(num);
    }

    public static void main(String[] args) {
        for (int i=0;i<10;i++) System.out.println(format(new Random().nextInt(3000),4));
    }
}
