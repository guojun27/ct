package ct.consumer;

import ct.commen.bean.Consumer;
import ct.consumer.bean.CalllogConsumer;

import java.io.IOException;

/**
 * 启动消费者
 * 使用kafka的消费者获取FLUME采集的数据
 *
 * 把数据存储到hbase中
 */
public class Bootstrap {
    public final static String ABC="ABC";
    public static void main(String[] args) throws Exception {
        //创建消费者
        Consumer consumer = new CalllogConsumer();
        //消费数据
        consumer.consume();
        //关闭资源
        consumer.close();
    }
}
