package ct.consumer.dao;


import ct.commen.bean.BaseDao;
import ct.commen.constant.Names;
import ct.commen.constant.ValueConstant;
import ct.consumer.bean.Calllog;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

import java.util.ArrayList;
import java.util.List;

public class HBaseDao extends BaseDao {
    /**
     * 初始化
     * @throws Exception
     */
    public void init() throws Exception{
        start();
        System.out.println(4);
        createNamespaceNX(Names.NAMESPACE.getValue());
        createTableXX(Names.TABLE.getValue(),"ct.consumer.coprocessor.InsertCalleeCoprocessor",
                ValueConstant.REGION_COUNT,Names.CF_CALLER.getValue());


        end();

    }
    public void insertData( Calllog log ) throws Exception {
        log.setRowkey(genRegionNum(log.getCall1(), log.getCalltime()) + "_" + log.getCall1() + "_" + log.getCalltime() + "_" + log.getCall2() + "_" + log.getDuration());

        putData(log);
    }
    /*
    插入数据
     */
    public void insertData(String value) throws Exception{
        //把通话日志保存到hbase表中
        //获取通话日志数据
        String[] values = value.split(("\t"));
        String call1 = values[0];
        String call2 = values[1];
        String calltime = values[2];
        String duration = values[3];
        //创建数据对象
        String rowkey = genRegionNum(call1, calltime) + "_" + call1 + "_" + calltime + "_" + call2 + "_" + duration + "_1";

        Put put = new Put(Bytes.toBytes(rowkey));

        byte[] family = Bytes.toBytes(Names.CF_CALLER.getValue());

        put.addColumn(family,Bytes.toBytes("call1"),Bytes.toBytes(call1));
        put.addColumn(family,Bytes.toBytes("call2"),Bytes.toBytes(call2));
        put.addColumn(family,Bytes.toBytes("calltime"),Bytes.toBytes(calltime));
        put.addColumn(family,Bytes.toBytes("duration"),Bytes.toBytes(duration));

        List<Put> puts = new ArrayList<Put>();
        puts.add(put);

        putData(Names.TABLE.getValue(),puts);

    }
}
