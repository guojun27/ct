package producer.bean;

import ct.commen.bean.Datain;
import ct.commen.bean.Dataout;
import ct.commen.bean.Producer;
import ct.commen.utill.DateUtil;
import ct.commen.utill.NumberUtil;


import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class LocalFileProducer implements Producer {
    private Datain in;
    private Dataout out;
    private volatile boolean flg = true;
    public void setIn(Datain in) {
        this.in = in;
    }

    public void setOut(Dataout out) {
        this.out = out;
    }

    public void produce() {
        try{
            List<Contact> contacts = in.read(Contact.class);
            while(flg){
                //从通讯录中查找2个电话号码作为主叫被叫
                int call1Index = new Random().nextInt(contacts.size());
                int call2Index;
                while(true){
                    call2Index = new Random().nextInt(contacts.size());
                    if(call1Index == call2Index){
                        break;
                    }
                }
                Contact call1 = contacts.get(call1Index);
                Contact call2 = contacts.get(call2Index);

                //生成随机的通话时间
                String startDate = "20200101000000";
                String endDate = "20210101000000";

                long startTime = DateUtil.parse(startDate,"yyyyMMddHHmmss").getTime();
                long endTime = DateUtil.parse(endDate,"yyyyMMddHHmmss").getTime();

                long calltime = startTime + (long)((endTime - startTime) * Math.random());
                String callTimeSting = DateUtil.format(new Date(calltime),"yyyyMMddHHmmss");

                //生成随机的通话时长
                String duration = NumberUtil.format(new Random().nextInt(3000),4);

                //生成通话记录
                Calllog log = new Calllog(call1.getTel(),call2.getTel(),callTimeSting,duration);
                //把通话记录写到数据文件
                out.write(log);
                System.out.println("数据存入完成");
                Thread.sleep(500);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void close() throws IOException {

    }
}
