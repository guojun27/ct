package producer.io;

import ct.commen.bean.Data;
import ct.commen.bean.Datain;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 *本地文件数据输入
 */
public class LocalFileDatain implements Datain {

    private BufferedReader reader = null;

    public LocalFileDatain(String path){setPath(path);}
    public void setPath(String path) {
        try{
            reader = new BufferedReader( new InputStreamReader( new FileInputStream(path), "UTF-8" ));
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public Object read() throws IOException {
        return null;
    }

    /**
     * 读取数据，返回数据集合。
     * @param clazz
     * @param <T>
     * @return
     * @throws IOException
     */
    public <T extends Data> List<T> read(Class<T> clazz) throws IOException {
        List<T> ts = new ArrayList<T>();

        try{
            String line = null;
            while ((line = reader.readLine())!=null){
                T t = clazz.newInstance();
                t.setValue(line);
                ts.add(t);
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }
        return ts;
    }
    //关闭资源数据
    public void close() throws  IOException{
        if(reader != null){
            reader.close();
        }
    }
}
