package producer;

import ct.commen.bean.Producer;
import producer.bean.LocalFileProducer;
import producer.io.LocalFileDataOut;
import producer.io.LocalFileDatain;

import java.io.IOException;


public class Bootstrap {
    public static void main(String[] args) throws IOException, IOException {

        if(args.length<2){
            System.out.println("系统参数不正确");
            System.exit(1);
        }

        //构建生产者对象
        Producer producer = new LocalFileProducer();
        producer.setIn(new LocalFileDatain(args[0]));
        producer.setOut(new LocalFileDataOut(args[1]));
//        producer.setIn(new LocalFileDatain("D:\\BaiduNetdiskDownload\\contact.log"));
//
//        producer.setOut(new LocalFileDataOut("D:\\BaiduNetdiskDownload\\call.log"));
        //生产数据
        producer.produce();
        System.out.println(producer);
        //关闭生产者对象
        producer.close();


    }
}
