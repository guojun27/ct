package ct.analysis;

import ct.analysis.tool.AnalysisBeanTool;
import org.apache.hadoop.util.ToolRunner;

public class AnalysisData {
    public static void main(String[] args) {
        int result = ToolRunner.run(new AnalysisBeanTool(),args);
    }
}
